export const validatePost = (data) => {
  const errors = {};
  if (!data.title?.trim()) errors.title = "Title is required";
  if (!data.author?.trim()) errors.author = "Author is required";
  if (!data.content?.trim()) errors.content = "Content is required";
  else if (data.content.length < 50)
    errors.content = "Content must be at least 50 characters";
  return errors;
};