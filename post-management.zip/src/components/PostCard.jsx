import { Link } from "react-router-dom";

export default function PostCard({ post, onDelete }) {
  return (
    <div className="card">
      <h3>{post.title}</h3>
      <p className="meta">By {post.author}</p>
      <p>{post.content.slice(0, 100)}...</p>
      <div className="card-actions">
        <Link to={`/posts/${post.id}`}>View</Link>
        <Link to={`/posts/${post.id}/edit`}>Edit</Link>
        <button onClick={() => onDelete(post.id)}>Delete</button>
      </div>
    </div>
  );
}