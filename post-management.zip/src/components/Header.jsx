import { Link } from "react-router-dom";

export default function Header() {
  return (
    <header className="header">
      <h1>Post Admin</h1>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/posts/new">Create Post</Link>
      </nav>
    </header>
  );
}