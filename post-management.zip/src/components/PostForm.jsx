import { useState } from "react";
import { validatePost } from "../utils/validators";

export default function PostForm({ initialData, onSubmit }) {
  const [form, setForm] = useState(initialData);
  const [errors, setErrors] = useState({});

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validatePost(form);
    setErrors(errs);
    if (Object.keys(errs).length === 0) onSubmit(form);
  };

  return (
    <form onSubmit={handleSubmit} className="form">
      <label>Title</label>
      <input name="title" value={form.title} onChange={handleChange} />
      {errors.title && <span className="error">{errors.title}</span>}

      <label>Author</label>
      <input name="author" value={form.author} onChange={handleChange} />
      {errors.author && <span className="error">{errors.author}</span>}

      <label>Content</label>
      <textarea name="content" value={form.content} onChange={handleChange} />
      {errors.content && <span className="error">{errors.content}</span>}

      <label>Tags (comma separated)</label>
      <input name="tags" value={form.tags} onChange={handleChange} />

      <button type="submit">Submit</button>
    </form>
  );
}