import { useNavigate, useParams } from "react-router-dom";
import useLocalStorage from "../hooks/useLocalStorage";
import PostForm from "../components/PostForm";

export default function PostEdit() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [posts, setPosts] = useLocalStorage("posts", []);

  const post = posts.find((p) => p.id === id);
  if (!post) return <p>Post not found</p>;

  const handleSubmit = (data) => {
    const updated = posts.map((p) =>
      p.id === id
        ? {
            ...p,
            ...data,
            tags: data.tags.split(",").map((t) => t.trim()),
            updatedAt: new Date().toISOString(),
          }
        : p
    );
    setPosts(updated);
    navigate(`/posts/${id}`);
  };

  return (
    <PostForm
      initialData={{ ...post, tags: post.tags.join(", ") }}
      onSubmit={handleSubmit}
    />
  );
}