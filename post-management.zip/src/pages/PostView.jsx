import { Link, useParams } from "react-router-dom";
import useLocalStorage from "../hooks/useLocalStorage";

export default function PostView() {
  const { id } = useParams();
  const [posts] = useLocalStorage("posts", []);

  const post = posts.find((p) => p.id === id);
  if (!post) return <p>Post not found</p>;

  return (
    <div className="container">
      <h2>{post.title}</h2>
      <p>By {post.author}</p>
      <p>{post.content}</p>

      <div className="tags">
        {post.tags.map((tag) => (
          <span key={tag} className="chip">{tag}</span>
        ))}
      </div>

      <p>Created: {new Date(post.createdAt).toLocaleString()}</p>
      <p>Updated: {new Date(post.updatedAt).toLocaleString()}</p>

      <Link to="/">⬅ Back to list</Link>
    </div>
  );
}