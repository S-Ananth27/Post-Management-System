import { useNavigate } from "react-router-dom";
import { v4 as uuidv4 } from "uuid";
import useLocalStorage from "../hooks/useLocalStorage";
import PostForm from "../components/PostForm";

export default function PostCreate() {
  const navigate = useNavigate();
  const [posts, setPosts] = useLocalStorage("posts", []);

  const handleSubmit = (data) => {
    const now = new Date().toISOString();
    const newPost = {
      id: uuidv4(),
      ...data,
      tags: data.tags ? data.tags.split(",").map((t) => t.trim()) : [],
      createdAt: now,
      updatedAt: now,
    };
    setPosts([...posts, newPost]);
    navigate("/");
  };

  return (
    <PostForm
      initialData={{ title: "", author: "", content: "", tags: "" }}
      onSubmit={handleSubmit}
    />
  );
}