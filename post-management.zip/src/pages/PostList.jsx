import { useMemo, useState } from "react";
import { v4 as uuidv4 } from "uuid";
import useLocalStorage from "../hooks/useLocalStorage";
import PostCard from "../components/PostCard";
import Pagination from "../components/Pagination";

const seedPosts = () =>
  Array.from({ length: 10 }).map((_, i) => ({
    id: uuidv4(),
    title: `Sample Post ${i + 1}`,
    author: i % 2 === 0 ? "Piyush" : "Admin",
    content:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.".repeat(2),
    tags: ["react", "blog"],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }));

export default function PostList() {
  const [posts, setPosts] = useLocalStorage("posts", seedPosts());
  const [search, setSearch] = useState("");
  const [author, setAuthor] = useState("");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    return posts.filter(
      (p) =>
        p.title.toLowerCase().includes(search.toLowerCase()) &&
        (author ? p.author === author : true)
    );
  }, [posts, search, author]);

  const perPage = 5;
  const totalPages = Math.ceil(filtered.length / perPage) || 1;
  const paginated = filtered.slice((page - 1) * perPage, page * perPage);

  const deletePost = (id) => {
    if (confirm("Delete this post?")) {
      setPosts(posts.filter((p) => p.id !== id));
      alert("Deleted successfully");
    }
  };

  const authors = [...new Set(posts.map((p) => p.author))];

  return (
    <div className="container">
      <h2>Posts</h2>
      <input
        placeholder="Search by title..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <select value={author} onChange={(e) => setAuthor(e.target.value)}>
        <option value="">All Authors</option>
        {authors.map((a) => (
          <option key={a}>{a}</option>
        ))}
      </select>

      {paginated.length === 0 ? (
        <p>No posts found</p>
      ) : (
        <div className="grid">
          {paginated.map((post) => (
            <PostCard key={post.id} post={post} onDelete={deletePost} />
          ))}
        </div>
      )}

      <Pagination page={page} totalPages={totalPages} setPage={setPage} />
    </div>
  );
}